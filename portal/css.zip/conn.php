<?php
$dbhost = 'localhost:3306';
$dbusername = 'h222937_hafteno';
$dbpassword = '70127074Aa$';
$dbname = 'h222937_hafteno';

// Create a connection
$conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

// Check connection
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}
?>
