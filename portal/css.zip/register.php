<?php 
include 'functions.php';
?>